echo hostname >> times.txt
for th in 16
do

echo export OMP_NUM_THREADS=$th
export OMP_NUM_THREADS=$th

echo Paralelo1 10000 
echo Paralelo1 10000 >> times.txt
./OddEven 10000 PAR1 >> times.txt
./OddEven 10000 PAR1 >> times.txt
./OddEven 10000 PAR1 >> times.txt
echo Paralelo1 50000
echo Paralelo1 50000 >> times.txt
./OddEven 50000 PAR1 >> times.txt
./OddEven 50000 PAR1 >> times.txt
./OddEven 50000 PAR1 >> times.txt
echo Paralelo1 100000
echo Paralelo1 100000 >> times.txt
./OddEven 100000 PAR1 >> times.txt
./OddEven 100000 PAR1 >> times.txt
./OddEven 100000 PAR1 >> times.txt
echo Paralelo1 150000
echo Paralelo1 150000 >> times.txt
./OddEven 150000 PAR1 >> times.txt
./OddEven 150000 PAR1 >> times.txt
./OddEven 150000 PAR1 >> times.txt
echo Paralelo1 200000
echo Paralelo1 200000 >> times.txt
./OddEven 200000 PAR1 >> times.txt
./OddEven 200000 PAR1 >> times.txt
./OddEven 200000 PAR1 >> times.txt

echo Paralelo2 10000 
echo Paralelo2 10000 >> times.txt
./OddEven 10000 PAR2 >> times.txt
./OddEven 10000 PAR2 >> times.txt
./OddEven 10000 PAR2 >> times.txt
echo Paralelo2 50000
echo Paralelo2 50000 >> times.txt
./OddEven 50000 PAR2 >> times.txt
./OddEven 50000 PAR2 >> times.txt
./OddEven 50000 PAR2 >> times.txt
echo Paralelo2 100000
echo Paralelo2 100000 >> times.txt
./OddEven 100000 PAR2 >> times.txt
./OddEven 100000 PAR2 >> times.txt
./OddEven 100000 PAR2 >> times.txt
echo Paralelo2 150000
echo Paralelo2 150000 >> times.txt
./OddEven 150000 PAR2 >> times.txt
./OddEven 150000 PAR2 >> times.txt
./OddEven 150000 PAR2 >> times.txt
echo Paralelo2 200000
echo Paralelo2 200000 >> times.txt
./OddEven 200000 PAR2 >> times.txt
./OddEven 200000 PAR2 >> times.txt
./OddEven 200000 PAR2 >> times.txt

echo Paralelo Unroll 1 10000 
echo Paralelo Unroll 1 10000 >> times.txt
./OddEven 10000 PARS1 >> times.txt
./OddEven 10000 PARS1 >> times.txt
./OddEven 10000 PARS1 >> times.txt
echo Paralelo Unroll 1 50000
echo Paralelo Unroll 1 50000 >> times.txt
./OddEven 50000 PARS1 >> times.txt
./OddEven 50000 PARS1 >> times.txt
./OddEven 50000 PARS1 >> times.txt
echo Paralelo Unroll 1 100000
echo Paralelo Unroll 1 100000 >> times.txt
./OddEven 100000 PARS1 >> times.txt
./OddEven 100000 PARS1 >> times.txt
./OddEven 100000 PARS1 >> times.txt
echo Paralelo Unroll 1 150000
echo Paralelo Unroll 1 150000 >> times.txt
./OddEven 150000 PARS1 >> times.txt
./OddEven 150000 PARS1 >> times.txt
./OddEven 150000 PARS1 >> times.txt
echo Paralelo Unroll 1 200000
echo Paralelo Unroll 1 200000 >> times.txt
./OddEven 200000 PARS1 >> times.txt
./OddEven 200000 PARS1 >> times.txt
./OddEven 200000 PARS1 >> times.txt

echo Paralelo Unroll 2 10000 
echo Paralelo Unroll 2 10000 >> times.txt
./OddEven 10000 PARS2 >> times.txt
./OddEven 10000 PARS2 >> times.txt
./OddEven 10000 PARS2 >> times.txt
echo Paralelo Unroll 2 50000
echo Paralelo Unroll 2 50000 >> times.txt
./OddEven 50000 PARS2 >> times.txt
./OddEven 50000 PARS2 >> times.txt
./OddEven 50000 PARS2 >> times.txt
echo Paralelo Unroll 2 100000
echo Paralelo Unroll 2 100000 >> times.txt
./OddEven 100000 PARS2 >> times.txt
./OddEven 100000 PARS2 >> times.txt
./OddEven 100000 PARS2 >> times.txt
echo Paralelo Unroll 2 150000
echo Paralelo Unroll 2 150000 >> times.txt
./OddEven 150000 PARS2 >> times.txt
./OddEven 150000 PARS2 >> times.txt
./OddEven 150000 PARS2 >> times.txt
echo Paralelo Unroll 2 200000
echo Paralelo Unroll 2 200000 >> times.txt
./OddEven 200000 PARS2 >> times.txt
./OddEven 200000 PARS2 >> times.txt
./OddEven 200000 PARS2 >> times.txt
done

echo Serial 10000 
echo Seria1 10000 >> times.txt
./OddEven 10000 SERIAL >> times.txt
./OddEven 10000 SERIAL >> times.txt
./OddEven 10000 SERIAL >> times.txt
echo Serial 50000
echo Serial 50000 >> times.txt
./OddEven 50000 SERIAL >> times.txt
./OddEven 50000 SERIAL >> times.txt
./OddEven 50000 SERIAL >> times.txt
echo Serial 100000
echo Serial 100000 >> times.txt
./OddEven 100000 SERIAL >> times.txt
./OddEven 100000 SERIAL >> times.txt
./OddEven 100000 SERIAL >> times.txt
echo Serial 150000
echo Serial 150000 >> times.txt
./OddEven 150000 SERIAL >> times.txt
./OddEven 150000 SERIAL >> times.txt
./OddEven 150000 SERIAL >> times.txt
echo Serial 200000
echo Serial 200000 >> times.txt
./OddEven 200000 SERIAL >> times.txt
./OddEven 200000 SERIAL >> times.txt
./OddEven 200000 SERIAL >> times.txt


