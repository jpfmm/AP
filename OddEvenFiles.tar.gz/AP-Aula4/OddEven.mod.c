#ifdef _POMP
#  undef _POMP
#endif
#define _POMP 200110

#include "OddEven.c.opari.inc"
#line 1 "OddEven.c"
#include <stdio.h>
#include <stdlib.h>
#include <time.h> 
#include <string.h>

void OESortUn(int NN, int *A){
	int i, exch0, exch1=1, fst = 1;
	
POMP_Parallel_fork(&omp_rd_1);
#line 10 "OddEven.c"
	#pragma omp parallel shared(exch0, exch1, fst) POMP_DLIST_00001
{ POMP_Parallel_begin(&omp_rd_1);
#line 11 "OddEven.c"
	{
	int temp;
	while(exch1==1){
POMP_Barrier_enter(&omp_rd_2);
#line 14 "OddEven.c"
	#pragma omp barrier
POMP_Barrier_exit(&omp_rd_2);
#line 15 "OddEven.c"
        exch0=0;
        exch1=0;
POMP_For_enter(&omp_rd_3);
#line 17 "OddEven.c"
        #pragma omp for nowait
	for(i = 0; i < NN-1; i+=2){
	    if(A[i] > A[i+1]){
		temp = A[i]; A[i] = A[i+1]; A[i+1] = temp;
		exch0 = 1;	
	    }
	}
POMP_Barrier_enter(&omp_rd_3);
#pragma omp barrier
POMP_Barrier_exit(&omp_rd_3);
POMP_For_exit(&omp_rd_3);
#line 24 "OddEven.c"
	if(exch0 == 1 || fst == 1){
POMP_For_enter(&omp_rd_4);
#line 25 "OddEven.c"
	   #pragma omp for nowait
	   for(i = 1; i < NN-1; i+=2){
		if(A[i] > A[i+1]){
		   temp = A[i]; A[i] = A[i+1]; A[i+1] = temp;
		   exch1 = 1;
		}
	   }
POMP_Barrier_enter(&omp_rd_4);
#pragma omp barrier
POMP_Barrier_exit(&omp_rd_4);
POMP_For_exit(&omp_rd_4);
#line 32 "OddEven.c"
	}     
        fst=0;
	}

	}
POMP_Barrier_enter(&omp_rd_1);
#pragma omp barrier
POMP_Barrier_exit(&omp_rd_1);
POMP_Parallel_end(&omp_rd_1); }
POMP_Parallel_join(&omp_rd_1);
#line 37 "OddEven.c"
}

void OESortUnroll(int NN, int *A){
	int i, exch0, exch1=1, fst = 1;
	
	while(exch1==1){
	     exch0=0;
	     exch1=0;

POMP_Parallel_fork(&omp_rd_5);
#line 46 "OddEven.c"
	     #pragma omp parallel shared(exch0, exch1, fst) POMP_DLIST_00005
{ POMP_Parallel_begin(&omp_rd_5);
#line 47 "OddEven.c"
	     {
		int temp;
POMP_For_enter(&omp_rd_6);
#line 49 "OddEven.c"
		#pragma omp for nowait
		for(i = 0; i < NN-1; i+=2){
		    if(A[i] > A[i+1]){
			temp = A[i]; A[i] = A[i+1]; A[i+1] = temp;
			exch0 = 1;	
		    }
		}
POMP_Barrier_enter(&omp_rd_6);
#pragma omp barrier
POMP_Barrier_exit(&omp_rd_6);
POMP_For_exit(&omp_rd_6);
#line 56 "OddEven.c"
		if(exch0 == 1 || fst == 1){
POMP_For_enter(&omp_rd_7);
#line 57 "OddEven.c"
		   #pragma omp for nowait
		   for(i = 1; i < NN-1; i+=2){
			if(A[i] > A[i+1]){
			   temp = A[i]; A[i] = A[i+1]; A[i+1] = temp;
			   exch1 = 1;
			}
		   }
POMP_Barrier_enter(&omp_rd_7);
#pragma omp barrier
POMP_Barrier_exit(&omp_rd_7);
POMP_For_exit(&omp_rd_7);
#line 64 "OddEven.c"
		}
	     }
POMP_Barrier_enter(&omp_rd_5);
#pragma omp barrier
POMP_Barrier_exit(&omp_rd_5);
POMP_Parallel_end(&omp_rd_5); }
POMP_Parallel_join(&omp_rd_5);
#line 66 "OddEven.c"
	     fst=0;
	}

}

void OESortPPP(int NN, int *A){
	int exch, i, start = 0, nthreads, fst=1; 
POMP_Parallel_fork(&omp_rd_8);
#line 73 "OddEven.c"
	#pragma omp parallel shared(exch, i, start, nthreads, fst) POMP_DLIST_00008
{ POMP_Parallel_begin(&omp_rd_8);
#line 74 "OddEven.c"
	{
	 int temp;
	 nthreads = omp_get_num_threads();
	 while(1){   
POMP_For_enter(&omp_rd_9);
#line 78 "OddEven.c"
	   #pragma omp for nowait
	   for(i = start; i < NN-1; i+=2){
		if(A[i] > A[i+1]){
		  temp = A[i]; A[i] = A[i+1]; A[i+1] = temp;
		  exch = nthreads;
		}
	   }
POMP_Barrier_enter(&omp_rd_9);
#pragma omp barrier
POMP_Barrier_exit(&omp_rd_9);
POMP_For_exit(&omp_rd_9);
#line 85 "OddEven.c"
	   if(exch == 0 && start == 0 && fst == 0){break;}	 
  
POMP_Critical_enter(&omp_rd_10);
#line 87 "OddEven.c"
	   #pragma omp critical
{ POMP_Critical_begin(&omp_rd_10);
#line 88 "OddEven.c"
	   {exch--;}
POMP_Critical_end(&omp_rd_10); }
POMP_Critical_exit(&omp_rd_10);
#line 89 "OddEven.c"

POMP_Single_enter(&omp_rd_11);
#line 90 "OddEven.c"
	   #pragma omp single nowait
{ POMP_Single_begin(&omp_rd_11);
#line 91 "OddEven.c"
	   start = 1 - start;
POMP_Single_end(&omp_rd_11); }
POMP_Barrier_enter(&omp_rd_11);
#pragma omp barrier
POMP_Barrier_exit(&omp_rd_11);
POMP_Single_exit(&omp_rd_11);
#line 92 "OddEven.c"
POMP_Single_enter(&omp_rd_12);
#line 92 "OddEven.c"
	   #pragma omp single nowait
{ POMP_Single_begin(&omp_rd_12);
#line 93 "OddEven.c"
	   if(fst == 1){fst=0;}
POMP_Single_end(&omp_rd_12); }
POMP_Single_exit(&omp_rd_12);
#line 94 "OddEven.c"
	 }
	}
POMP_Barrier_enter(&omp_rd_8);
#pragma omp barrier
POMP_Barrier_exit(&omp_rd_8);
POMP_Parallel_end(&omp_rd_8); }
POMP_Parallel_join(&omp_rd_8);
#line 96 "OddEven.c"

}


void OESortPP(int NN, int *A)
{
        int exch0, exch1=0, fst = 1, i, start = 0;
POMP_Parallel_fork(&omp_rd_13);
#line 103 "OddEven.c"
        #pragma omp parallel shared(start, fst, A, exch0, exch1, NN) private(i) POMP_DLIST_00013
{ POMP_Parallel_begin(&omp_rd_13);
#line 104 "OddEven.c"
	{
	    int temp;
	    while(1) {
               if(exch1==0 && start==0 && fst==0){break;}
POMP_Barrier_enter(&omp_rd_14);
#line 108 "OddEven.c"
	       #pragma omp barrier
POMP_Barrier_exit(&omp_rd_14);
#line 109 "OddEven.c"
	       
	       if(start==0){exch0 = 0;}	       
POMP_Atomic_enter(&omp_rd_15);
#line 111 "OddEven.c"
	       #pragma omp atomic
  	       exch1--;
POMP_Atomic_exit(&omp_rd_15);
#line 113 "OddEven.c"

	       if(start==0 || exch0==1 || fst==1){
	       //#pragma omp barrier
POMP_For_enter(&omp_rd_16);
#line 116 "OddEven.c"
	       #pragma omp for nowait
	       for (i = start; i < NN-1; i+=2) {
                  if (A[i] > A[i+1]) {        
		     temp = A[i]; A[i] = A[i+1]; A[i+1] = temp;      
POMP_Critical_enter(&omp_rd_17);
#line 120 "OddEven.c"
		     #pragma omp critical
{ POMP_Critical_begin(&omp_rd_17);
#line 121 "OddEven.c"
		     {
		     if(start==0){exch0 = 1;}
		     else{exch1 = omp_get_num_threads();}
		     }
POMP_Critical_end(&omp_rd_17); }
POMP_Critical_exit(&omp_rd_17);
#line 125 "OddEven.c"
                  }
               }
POMP_Barrier_enter(&omp_rd_16);
#pragma omp barrier
POMP_Barrier_exit(&omp_rd_16);
POMP_For_exit(&omp_rd_16);
#line 127 "OddEven.c"
	       }

POMP_Barrier_enter(&omp_rd_18);
#line 129 "OddEven.c"
	       #pragma omp barrier
POMP_Barrier_exit(&omp_rd_18);
#line 130 "OddEven.c"
POMP_Single_enter(&omp_rd_19);
#line 130 "OddEven.c"
	       #pragma omp single nowait
{ POMP_Single_begin(&omp_rd_19);
#line 131 "OddEven.c"
	       start = 1 - start;
POMP_Single_end(&omp_rd_19); }
POMP_Single_exit(&omp_rd_19);
#line 132 "OddEven.c"
	       
	       if(fst==1&&start==0){fst = 0;}
	    }
	}
POMP_Barrier_enter(&omp_rd_13);
#pragma omp barrier
POMP_Barrier_exit(&omp_rd_13);
POMP_Parallel_end(&omp_rd_13); }
POMP_Parallel_join(&omp_rd_13);
#line 136 "OddEven.c"
}

void OESortP(int NN, int *A)
{
	int exch = 1, start = 0, i;
	int temp;
	//#pragma omp parallel shared(start, A, exch, NN, temp) private(i)
	while (exch || start) {
		exch = 0;	
POMP_Parallel_fork(&omp_rd_20);
#line 145 "OddEven.c"
		#pragma omp parallel     shared(exch, A, start, NN) private(temp)
{ POMP_Parallel_begin(&omp_rd_20);
POMP_For_enter(&omp_rd_20);
#line 145 "OddEven.c"
  #pragma omp          for                                          nowait
		for (i = start; i < NN-1; i+=2) {
			if (A[i] > A[i+1]) {
				temp = A[i]; A[i] = A[i+1]; A[i+1] = temp;
				exch = 1;
			}
		}
POMP_Barrier_enter(&omp_rd_20);
#pragma omp barrier
POMP_Barrier_exit(&omp_rd_20);
POMP_For_exit(&omp_rd_20);
POMP_Parallel_end(&omp_rd_20); }
POMP_Parallel_join(&omp_rd_20);
#line 152 "OddEven.c"
		//#pragma omp single
		if (start == 0) start = 1;
		else start = 0;
	}
}

void OESort(int NN, int *A)
{
	int exch = 1, start = 0, i;
	int temp;

	while (exch || start) {
		exch = 0;
		for (i = start; i < NN-1; i+=2) {
			if (A[i] > A[i+1]) {
				temp = A[i]; A[i] = A[i+1]; A[i+1] = temp;
				exch = 1;
			}
		}
		if (start == 0) start = 1;
		else start = 0;
	}
}

void init_data(int *A, int N)
{
	int i;
	for (i = 0; i < N/2; i++)
		A[i] = i + N/2;
	//	A[i] = rand() % N;
	for (i = N/2; i < N; i++)
		A[i] = i - N/2;
}

int main(int argc, char* argv[])
{	
	//int i, j;
	time_t ini, fim;
	//init_data();
	
	if(argc!=3){printf("Argumentos invalidos\nOddEven <size> <arg>\n");exit(0);}
	int N = atoi(argv[1]);
	char *arg = argv[2];
	
	printf("arg: %s\n",arg);

	int A[N];
	init_data(A,N);
	if(strcmp(arg,"SERIAL")==0){
	    ini = time(NULL);
	    OESort(N,A);
	    fim = time(NULL);
	    printf("Tempo Serial: %f, size: %d\n", difftime(fim,ini),N);	
	}else if(strcmp(arg,"PAR1")==0){
	    ini = time(NULL);
	    OESortP(N,A);
	    fim = time(NULL);
	    printf("Tempo Paralelo JSP: %f, size: %d\n", difftime(fim,ini),N);
	}else if(strcmp(arg,"PAR2")==0){
	    ini = time(NULL);
	    OESortP(N,A);
	    fim = time(NULL);
	    printf("Tempo Paralelo JNP: %f, size: %d\n", difftime(fim,ini),N);	
	}else if(strcmp(arg,"PARS1")==0){
	    ini = time(NULL);
	    OESortP(N,A);
	    fim = time(NULL);
	    printf("Tempo Paralelo SSP: %f, size: %d\n", difftime(fim,ini),N);
	}else if(strcmp(arg,"PARS2")==0){
	    ini = time(NULL);
	    OESortP(N,A);
	    fim = time(NULL);
	    printf("Tempo Paralelo SNP: %f, size: %d\n", difftime(fim,ini),N);
	}
	
	//for ( i = 0; i < N; i++) printf("%3d ",A[i]);
	//printf("\n\n");

	//OESort(N,A);
	//for ( j = 0; j < N; j++) printf("%3d ",A[j]);
	//printf("\n\n");
	
	//init_data();
	//for ( i = 0; i < N; i++) printf("%3d ",A[i]);
	//printf("\n\n");
	//ini = time(NULL);
	//OESortUn(N,A);
	//fim = time(NULL);
	//printf("Tempo Paralelo2: %f, size: %d\n", difftime(fim,ini),N);
	//for ( j = 0; j < N; j++) printf("%3d ",A[j]);
	return 0;
}
