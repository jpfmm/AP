#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <mpi.h>
#include "mapreduce.h"
#include "keyvalue.h"

using namespace MAPREDUCE_NS;


int gcd(int u, int v)
{
if (v == 0) return u;
return gcd(v, u % v);
}

typedef struct K{
    int num;
    int den;
}Chave;

typedef struct in{
    int start;
    int end;
    int* the_num;
    int* num;
    int* den;
}Input;

void mymap(int nprocs, KeyValue *key, void *ptr){
    Input *inp = (Input*) ptr;
    int last = inp->end - inp->start + 1;
    int i, j, factor, ii, sum, done, n;
  
    for(i=inp->start; i<=inp->end; i++){
	ii = i - inp->start;
	sum = 1 + i;
	inp->the_num[ii] = i;
	done = i;
	factor = 2;
	while (factor < done){
	   if((i % factor) == 0){
		sum += (factor +(i/factor));
		if((done = i/factor) == factor) sum -= factor;
	   }
	   factor++;
	}
        inp->num[ii] = sum; inp->den[ii] = i;
    	n = gcd(inp->num[ii],inp->den[ii]);
    	inp->num[ii] /= n;
    	inp->den[ii] /= n;
    	Chave c;
    	c.num = inp->num[ii];
    	c.den = inp->den[ii];
    	int n = inp->the_num[ii];
    	key->add((char *)&c,sizeof(Chave),(char*) &n,sizeof(int)); 
    }
}

void transform(int* numb, char* mv, int nv, int* vb){
    int* values = (int*) mv;
    for(int i = 0; i < nv; i++){
	numb[i] = values[i];
    }
}

void myreduce(char *key, int keybytes, char *multivalue, int nvalues, int *valuebytes, KeyValue *k, void *ptr){
    int* numbers=(int*)malloc(sizeof(int)*nvalues);
    int i;
    transform(numbers,multivalue,nvalues,valuebytes);
    if(nvalues>1){
	printf("Friendly numbers: \n");
	for(i = 0; i < nvalues; i++){
	    printf(" %d ",numbers[i]);
	}
	printf("\n");
    }
}

int main(int argc, char **argv)
{
    unsigned int start = atoi(argv[1]);
    unsigned int end = atoi(argv[2]);
    
    int rank, size, last = end - start + 1;

    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
    MPI_Comm_size(MPI_COMM_WORLD,&size);

    int mystart = (last+1)/size * rank;
    int myend = (last+1)/size * (rank+1) - 1;
    if(rank == size-1){myend += (last+1) % size;}
    int mycharge = myend - mystart + 1;


    Input inp;

    inp.start = mystart;
    inp.end = myend;

    int* the_num = (int*)malloc(sizeof(int)*mycharge);
    int* num = (int*)malloc(sizeof(int)*mycharge);
    int* den = (int*)malloc(sizeof(int)*mycharge);

    inp.the_num = the_num
    inp.num = num;
    inp.den = den;

    MapReduce *mr = new MapReduce(MPI_COMM_WORLD);
    mr->verbosity = 0;
    mr->timer = 1;

    MPI_Barrier(MPI_COMM_WORLD);

    double ini = MPI_Wtime();
 
    int m = mr->map(size,&mymap,&inp);

    mr->collate(NULL);

    int nunique = mr->reduce(&myreduce,&inp);

    delete mr;

    MPI_Barrier(MPI_COMM_WORLD);

    double fim = MPI_Wtime();
    if(rank==0)printf("Tempo total: %f\n",fim-ini);

    MPI_Finalize();
}
