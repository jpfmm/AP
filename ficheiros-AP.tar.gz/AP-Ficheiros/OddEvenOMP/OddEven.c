#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <time.h> 
#include <string.h>

void OESortUn(int NN, int *A){
	int i, exch0, exch1=1, fst = 1;
	
	#pragma omp parallel shared(exch0, exch1, fst)
	{
	int temp;
	while(exch1==1){
	#pragma omp barrier
        exch0=0;
        exch1=0;
        #pragma omp for
	for(i = 0; i < NN-1; i+=2){
	    if(A[i] > A[i+1]){
		temp = A[i]; A[i] = A[i+1]; A[i+1] = temp;
		exch0 = 1;	
	    }
	}
	if(exch0 == 1 || fst == 1){
	   #pragma omp for
	   for(i = 1; i < NN-1; i+=2){
		if(A[i] > A[i+1]){
		   temp = A[i]; A[i] = A[i+1]; A[i+1] = temp;
		   exch1 = 1;
		}
	   }
	}     
        fst=0;
	}

	}
}

void OESortUnroll(int NN, int *A){
	int i, exch0, exch1=1, fst = 1;
	
	while(exch1==1){
	     exch0=0;
	     exch1=0;

	     #pragma omp parallel shared(exch0, exch1, fst)
	     {
		int temp;
		#pragma omp for
		for(i = 0; i < NN-1; i+=2){
		    if(A[i] > A[i+1]){
			temp = A[i]; A[i] = A[i+1]; A[i+1] = temp;
			exch0 = 1;	
		    }
		}
		if(exch0 == 1 || fst == 1){
		   #pragma omp for
		   for(i = 1; i < NN-1; i+=2){
			if(A[i] > A[i+1]){
			   temp = A[i]; A[i] = A[i+1]; A[i+1] = temp;
			   exch1 = 1;
			}
		   }
		}
	     }
	     fst=0;
	}

}

void OESortPPP(int NN, int *A){
	int exch, i, start = 0, nthreads, fst=1; 
	#pragma omp parallel shared(exch, i, start, nthreads, fst)
	{
	 int temp;
	 nthreads = omp_get_num_threads();
	 while(1){   
	   #pragma omp for
	   for(i = start; i < NN-1; i+=2){
		if(A[i] > A[i+1]){
		  temp = A[i]; A[i] = A[i+1]; A[i+1] = temp;
		  exch = nthreads;
		}
	   }
	   if(exch == 0 && start == 0 && fst == 0){break;}	 
  
	   #pragma omp critical
	   {exch--;}

	   #pragma omp single
	   start = 1 - start;
	   #pragma omp single nowait
	   if(fst == 1){fst=0;}
	 }
	}

}


void OESortPP(int NN, int *A)
{
        int exch0, exch1=0, fst = 1, i, start = 0;
        #pragma omp parallel shared(start, fst, A, exch0, exch1, NN) private(i)
	{
	    int temp;
	    while(1) {
               if(exch1==0 && start==0 && fst==0){break;}
	       #pragma omp barrier
	       
	       if(start==0){exch0 = 0;}	       
	       #pragma omp atomic
  	       exch1--;

	       if(start==0 || exch0==1 || fst==1){
	       //#pragma omp barrier
	       #pragma omp for
	       for (i = start; i < NN-1; i+=2) {
                  if (A[i] > A[i+1]) {        
		     temp = A[i]; A[i] = A[i+1]; A[i+1] = temp;      
		     #pragma omp critical
		     {
		     if(start==0){exch0 = 1;}
		     else{exch1 = omp_get_num_threads();}
		     }
                  }
               }
	       }

	       #pragma omp barrier
	       #pragma omp single nowait
	       start = 1 - start;
	       
	       if(fst==1&&start==0){fst = 0;}
	    }
	}
}

void OESortP(int NN, int *A)
{
	int exch = 1, start = 0, i;
	int temp;
	//#pragma omp parallel shared(start, A, exch, NN, temp) private(i)
	while (exch || start) {
		exch = 0;	
		#pragma omp parallel for shared(exch, A, start, NN) private(temp)
		for (i = start; i < NN-1; i+=2) {
			if (A[i] > A[i+1]) {
				temp = A[i]; A[i] = A[i+1]; A[i+1] = temp;
				exch = 1;
			}
		}
		//#pragma omp single
		if (start == 0) start = 1;
		else start = 0;
	}
}

void OESort(int NN, int *A)
{
	int exch = 1, start = 0, i;
	int temp;

	while (exch || start) {
		exch = 0;
		for (i = start; i < NN-1; i+=2) {
			if (A[i] > A[i+1]) {
				temp = A[i]; A[i] = A[i+1]; A[i+1] = temp;
				exch = 1;
			}
		}
		if (start == 0) start = 1;
		else start = 0;
	}
}

void init_data(int *A, int N)
{
	int i;
	for (i = 0; i < N/2; i++)
		A[i] = i + N/2;
	//	A[i] = rand() % N;
	for (i = N/2; i < N; i++)
		A[i] = i - N/2;
}

int main(int argc, char* argv[])
{	
	//int i, j;
	time_t ini, fim;
	//init_data();
	
	if(argc!=3){printf("Argumentos invalidos\nOddEven <size> <arg>\n");exit(0);}
	int N = atoi(argv[1]);
	char *arg = argv[2];
	
	printf("arg: %s\n",arg);

	int A[N];
	init_data(A,N);
	if(strcmp(arg,"SERIAL")==0){
	    ini = time(NULL);
	    OESort(N,A);
	    fim = time(NULL);
	    printf("Tempo Serial: %f, size: %d\n", difftime(fim,ini),N);	
	}else if(strcmp(arg,"PAR1")==0){
	    ini = time(NULL);
	    OESortP(N,A);
	    fim = time(NULL);
	    printf("Tempo Paralelo JSP: %f, size: %d\n", difftime(fim,ini),N);
	}else if(strcmp(arg,"PAR2")==0){
	    ini = time(NULL);
	    OESortP(N,A);
	    fim = time(NULL);
	    printf("Tempo Paralelo JNP: %f, size: %d\n", difftime(fim,ini),N);	
	}else if(strcmp(arg,"PARS1")==0){
	    ini = time(NULL);
	    OESortP(N,A);
	    fim = time(NULL);
	    printf("Tempo Paralelo SSP: %f, size: %d\n", difftime(fim,ini),N);
	}else if(strcmp(arg,"PARS2")==0){
	    ini = time(NULL);
	    OESortP(N,A);
	    fim = time(NULL);
	    printf("Tempo Paralelo SNP: %f, size: %d\n", difftime(fim,ini),N);
	}
	
	//for ( i = 0; i < N; i++) printf("%3d ",A[i]);
	//printf("\n\n");

	//OESort(N,A);
	//for ( j = 0; j < N; j++) printf("%3d ",A[j]);
	//printf("\n\n");
	
	//init_data();
	//for ( i = 0; i < N; i++) printf("%3d ",A[i]);
	//printf("\n\n");
	//ini = time(NULL);
	//OESortUn(N,A);
	//fim = time(NULL);
	//printf("Tempo Paralelo2: %f, size: %d\n", difftime(fim,ini),N);
	//for ( j = 0; j < N; j++) printf("%3d ",A[j]);
	return 0;
}
