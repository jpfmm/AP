#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>
#include <time.h>
#include <mpi.h>

int gcd(int u, int v)
{
if (v == 0) return u;
return gcd(v, u % v);
}

/*
void FriendlyNumbers (int start, int end)
{
	int last = end-start+1;
	int *the_num = (int*)malloc(last*sizeof(int));
	int *num = (int*)malloc(last*sizeof(int));
	int *den = (int*)malloc(last*sizeof(int));
#pragma omp parallel
 {	int i, j, factor, ii, sum, done, n;
	// -- MAP --
	#pragma omp for schedule (dynamic, 16)
	for (i = start; i <= end; i++) {
		ii = i - start;
		sum = 1 + i;
		the_num[ii] = i;
		done = i;
		factor = 2;
		while (factor < done) {
			if ((i % factor) == 0) {
				sum += (factor + (i/factor));
				if ((done = i/factor) == factor) sum -= factor;
			}
			factor++;
		}
		num[ii] = sum; den[ii] = i;
		n = gcd(num[ii], den[ii]);
		num[ii] /= n;
		den[ii] /= n;
	} // end for
// -- REDUCE --
#pragma omp for schedule (static, 8)
	for (i = 0; i < last; i++) {
		for (j = i+1; j< last; j++) {
			if ((num[i] == num[j]) && (den[i] == den[j]))
				printf ("%d and %d are FRIENDLY \n", the_num[i], the_num[j]);
		}
	}
 } // end parallel region
	free(the_num);
	free(num);
	free(den);
}*/



int main(int argc, char **argv)
{
    unsigned int start = atoi(argv[1]);
    unsigned int end = atoi(argv[2]);
 
    long time = omp_get_wtime();
    //FriendlyNumbers(start, end);
    
    int rank, size;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int last = end - start + 1;
    int *the_num = (int*)malloc(last*sizeof(int));
    int *num = (int*)malloc(last*sizeof(int));
    int *den = (int*)malloc(last*sizeof(int));
    
    int i, j, factor, ii, sum, done, n;
    int mystart = (last+1)/size * rank;
    int myend = (last+1)/size * (rank+1) - 1;
    if(rank == size-1){myend += (last+1)%size;}

    int mycharge = myend - mystart + 1;

    int *mythe_num = (int*)malloc(mycharge*sizeof(int));
    int *mynum = (int*)malloc(mycharge*sizeof(int));
    int *myden = (int*)malloc(mycharge*sizeof(int));
    
    //printf("Processo: %d comecou MAP, nro procs: %d\n",rank,size);
    //--------------MAP---------------
    for (i = mystart; i <= myend; i++) {
       ii = i - mystart;
       sum = 1 + i;
       mythe_num[ii] = i;
       done = i;
       factor = 2;
       while (factor < done) {
          if ((i % factor) == 0) {
            sum += (factor + (i/factor));
            if ((done = i/factor) == factor) sum -= factor;
          }
          factor++;
       }
       mynum[ii] = sum; myden[ii] = i;
       n = gcd(mynum[ii], myden[ii]);
       mynum[ii] /= n;
       myden[ii] /= n;
    } 
    //printf("Processo: %d acabou MAP, vai comecar a sincronizacao\n",rank);
    if(rank==0){
	//insert rank 0 data in global one
	for(i=mystart; i<=myend; i++){
	   the_num[i] = mythe_num[i];
	   num[i] = mynum[i];
	   den[i] = myden[i];
	}
	//Recieve data from other processes
	for(i=1; i<size-1; i++){
	   MPI_Recv(&the_num[((last+1)/size*i)],mycharge,MPI_INT,i,i,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
           MPI_Recv(&num[((last+1)/size*i)],mycharge,MPI_INT,i,i,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
           MPI_Recv(&den[((last+1)/size*i)],mycharge,MPI_INT,i,i,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
 	   printf("Passou vetores de %d e guardou a partir de %d com %d valores\n",i,((last+1)/size*i),mycharge);
	}
 	//printf("Processo 0 recebeu de todos os processos menos o ultimo, com %d dados cada\n",mycharge);
	//Data from the last process
        MPI_Recv(&the_num[((last+1)/size*(size-1))],mycharge+(last+1)%size,MPI_INT,size-1,size-1,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
        MPI_Recv(&num[((last+1)/size*(size-1))],mycharge+(last+1)%size,MPI_INT,size-1,size-1,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
        MPI_Recv(&den[((last+1)/size*(size-1))],mycharge+(last+1)%size,MPI_INT,size-1,size-1,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
        //printf("Processo 0 recebeu de todos, com %d dados\n", mycharge+(last+1)%size);
    }else{
	//Send process data to 0
	MPI_Send(&mythe_num[0],mycharge,MPI_INT,0,rank,MPI_COMM_WORLD);
        MPI_Send(&mynum[0],mycharge,MPI_INT,0,rank,MPI_COMM_WORLD);
        MPI_Send(&myden[0],mycharge,MPI_INT,0,rank,MPI_COMM_WORLD);
    }

    MPI_Bcast(the_num,last,MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast(num,last,MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast(den,last,MPI_INT,0,MPI_COMM_WORLD);

    //printf("Processo: %d acabou sincronizacao. Comeca reduce\n",rank);

    //-----------REDUCE---------------
    printf("Processo: %d, mystart: %d, myend: %d\n",rank,mystart,myend);
    for (i = mystart; i <= myend; i++) {
       for (j = i+1; j< last; j++) {
          if ((num[i] == num[j]) && (den[i] == den[j]))
            printf("%d and %d are FRIENDLY, processo: %d, i=%d, j=%d \n", the_num[i], the_num[j],rank,i,j);
       }
    }

    //printf("Processo: %d acabou reduce\n",rank);

    MPI_Finalize();
    // end parallel region
    free(the_num);
    free(num);
    free(den);

    time = omp_get_wtime() - time;
    if(rank==0)printf("Tempo total: %ld\n",time);
}
